package com.theoc.pixhell.global;

import java.util.HashMap;

import com.theoc.pixhell.model.PersistentConsumable;

public class WeaponsCache {
	
public HashMap<PersistentConsumable,Integer> weaponsCache = new HashMap<PersistentConsumable,Integer>();
}
