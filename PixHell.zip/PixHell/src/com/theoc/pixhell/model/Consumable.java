package com.theoc.pixhell.model;

public interface Consumable {
}
