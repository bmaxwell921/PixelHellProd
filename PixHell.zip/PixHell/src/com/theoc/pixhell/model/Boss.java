package com.theoc.pixhell.model;

import com.theoc.pixhell.utilities.Vector2;

import android.graphics.Bitmap;

public class Boss extends Enemy {

	public Boss(Bitmap image) {
		super(image, Vector2.ZERO);
	}
}
