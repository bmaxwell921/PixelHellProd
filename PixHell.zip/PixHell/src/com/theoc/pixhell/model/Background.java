package com.theoc.pixhell.model;

import android.graphics.Bitmap;

public class Background extends GameObject {

	public Background(Bitmap image, int screenWidth, int screenHeight) {
		super(image, screenWidth, screenHeight);
	}
}
