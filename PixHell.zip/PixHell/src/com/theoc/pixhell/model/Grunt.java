package com.theoc.pixhell.model;

import android.graphics.Bitmap;

import com.theoc.pixhell.utilities.Vector2;

public class Grunt extends Enemy {

	public Grunt(Bitmap image, Vector2 position) {
		super(image, position);
	}
//	
//	public Grunt(Bitmap image, Vector2 position, Vector2 maxVel) {
//		super(image, position, maxVel);
//	}	
}
