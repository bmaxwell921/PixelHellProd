package com.theoc.pixhell.utilities;

public enum GameState {
	PAUSE, IN_WAVE, BETWEEN_WAVE, TEAR_DOWN, GAME_OVER
}
