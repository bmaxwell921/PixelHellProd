package com.theoc.pixhell.utilities;

public enum WeaponType {
	BULLET, MISSILE, TRI_BLASTER
}
