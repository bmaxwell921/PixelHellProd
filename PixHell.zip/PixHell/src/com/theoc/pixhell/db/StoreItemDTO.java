package com.theoc.pixhell.db;

import java.util.HashMap;

public class StoreItemDTO {
	public HashMap<String,Integer> data = new HashMap<String,Integer>();
}
